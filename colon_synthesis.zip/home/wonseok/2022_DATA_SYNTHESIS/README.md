# 2022_DATA_SYNTHESIS
- Author : Won Seok Jang
- Objective : Study and find new ways to synthesize data

---
## 0. prepare data
- takes raw files and outputs concatenated time series data
```{python}
$ ./0_prepare_data.sh
```

## 1. execute local differential privacy algorithm
- 