
from pandas import Series


def ldp_for_static(static : Series):
    
    
    