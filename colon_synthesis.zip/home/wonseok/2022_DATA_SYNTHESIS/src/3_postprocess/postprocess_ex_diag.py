#%%
import pandas as pd
import numpy as np
import pickle
import os, sys
from pathlib import Path
import argparse

PROJ_PATH = Path(__file__).parents[2]
sys.path.append(PROJ_PATH.joinpath('src').as_posix())

from MyModule.utils import *
config = load_config()

PROJ_PATH = Path(config['path_config']['project_path'])
INPUT_PATH = PROJ_PATH.joinpath('data/processed/2_restore/restore_to_db_form')
OUTPUT_PATH = PROJ_PATH.joinpath('data/processed/3_postprocess/')

if not OUTPUT_PATH.exists() :
    OUTPUT_PATH.mkdir(parents=True)

file_name = "CLRC_EX_DIAG"

# %%
def load_file_epsilon(epsilon):
    return read_file(INPUT_PATH, f'{file_name}_{epsilon}.pkl')


#%%
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--epsilon', '--e', help="epsilon values")
    args = parser.parse_args()
#%%
    data = load_file_epsilon(args.epsilon)

    original_path = PROJ_PATH.joinpath(f'data/raw/{file_name}.csv')
    head = pd.read_csv(original_path, nrows = 0)

    data_melted = pd.melt(data, id_vars=['PT_SBST_NO','TIME'])

    #%%
    data_melted = data_melted.rename(columns ={'TIME':'CEXM_YMD','variable':'CEXM_NM','value':'CEXM_RSLT_CONT'})

    data_melted = pd.concat([head,data_melted])

    original_data = pd.read_csv(original_path)
    
    reference = original_data[['CEXM_NM','CEXM_RSLT_UNIT_CONT','CEXM_RSLT_REF_CONT']].drop_duplicates().reset_index(drop=True)
    reference['CEXM_NM'] = reference.CEXM_NM.str.strip()
    del original_data

    #%%
    data_melted = data_melted.drop(columns = ['CEXM_RSLT_UNIT_CONT','CEXM_RSLT_REF_CONT'])

    data_melted = data_melted.merge(reference, on=['CEXM_NM'])
    #%%
    data_melted = data_melted[head.columns]

    #%%

    data_melted['CENTER_CD'] = 00000
    data_melted['IRB_APRV_NO'] = '2-2222-02-22'
    data_melted['CRTN_DT'] = '0200.0'
    data_melted['CEXM_SEQ'] = 0
    dtypes = head.dtypes.to_dict()
    #%%
    data['DEAD_YMD']= data['DEAD_YMD'].astype('datetime64[ns]')
    data = data.astype(dtypes)

    data.to_excel(OUTPUT_PATH.joinpath(f'{file_name}_{args.epsilon}'))
    pass

if __name__ == "__main__":
    main()